/** @type {import('tailwindcss').Config} */
const defaultTheme = require("tailwindcss/defaultTheme");
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      screens: {
        xs: { min: "0px", max: "640px" },
        ...defaultTheme.screens,
      },
      fontFamily: {
        Inter: ["Inter", "sans-serif"],
        poppins: ["Inter", "Poppins", "sans-serif"],
      },
      backgroundImage: {
        pageBackground: "url('/./src/assets/pagebg.png')",
        podcastbg: "url('/./src/assets/podcast1.png')",
        buttonbg: "linear-gradient(to right, #4776E6, #8E54E9)",
      },
    },
  },
  plugins: [],
};
