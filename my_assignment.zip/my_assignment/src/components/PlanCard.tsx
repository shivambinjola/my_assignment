import React from "react";

const PlanCard = ({ heading, property, text }: any) => {
  return (
    <div
      className={`w-[303px] h-[357px] border-[1px] border-[#7A3199] rounded-[10px] space-y-5 px-5 py-6 ${property} ${text}`}
    >
      <p className="text-sm font-Inter font-bold">{heading}</p>
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
      <p
        className={`${text} text-[32px] font-poppins font-bold flex items-center`}
      >
        $ 54 <span className="text-sm ml-5">/ month</span>
      </p>
      <ul className="text-xs font-Inter font-semibold list-disc list-inside">
        <li>Free access to video class</li>
        <li>Free access to video class</li>
        <li>Free access to video class</li>
      </ul>
      <button className="bg-white border-[1px] border-[#7A3199] py-4 px-8 text-xs font-poppins  rounded-[5px] text-[#7A3199]">
        Start Free Trial
      </button>
    </div>
  );
};

export default PlanCard;
