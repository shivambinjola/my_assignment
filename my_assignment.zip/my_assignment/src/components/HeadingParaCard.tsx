import React from "react";

interface myProps {
  heading: string;
  para: string;
}

const HeadingParaCard = (props: myProps) => {
  return (
    <div className="w-[268px] h-[160px] rounded-[10px] border-[1px] border-black p-7 space-y-4 font-poppins">
      <p className="text-[20px] font-semibold"> {props.heading}</p>
      <p className="text-xs font-normal">{props.para}</p>
    </div>
  );
};

export default HeadingParaCard;
