import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Keyboard } from "swiper";
import "swiper/css/bundle";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import prevIcon from "../assets/arrowicon.png";
import nextIcon from "../assets/arrowicon.png";
import Avatar from "../assets/avatar.png";

const SliderComp = () => {
  const navigationPrevRef = React.useRef<HTMLButtonElement>(null);
  const navigationNextRef = React.useRef<HTMLButtonElement>(null);
  return (
    <div
      className={`relative lg:px-0 space-y-2 sm:px-2 xs:px-2 flex items-center justify-center`}
    >
      <div className="flex items-center z-50 absolute">
        <div className="space-x-80 xs:hidden">
          <button
            ref={navigationPrevRef}
            className=" rotate-180 rounded-full bg-[#E1A6FF66]/40 p-4"
          >
            <img src={prevIcon} alt="" />
          </button>
          <button
            ref={navigationNextRef}
            className=" rounded-full bg-[#E1A6FF66]/40 p-4"
          >
            <img src={nextIcon} alt="" />
          </button>
        </div>
      </div>

      <div className="xl:w-[1500px] lg:w-[1000px] sm:w-[640px] xs:w-[350px]">
        <Swiper
          onInit={(swiper) => {
            // @ts-ignore
            swiper.params.navigation.prevEl = navigationPrevRef.current;
            // @ts-ignore
            swiper.params.navigation.nextEl = navigationNextRef.current;
            swiper.navigation.init();
            swiper.navigation.update();
          }}
          //   pagination={{
          //     clickable: true,
          //   }}
          breakpoints={{
            320: {
              slidesPerView: 1.2,
              spaceBetween: 15,
            },
            370: {
              slidesPerView: 1.2,
              spaceBetween: 15,
            },
            // when window width is >= 480px
            480: {
              slidesPerView: 1.3,
              spaceBetween: 10,
            },
            1024: {
              slidesPerView: 2,
              spaceBetween: 10,
            },
            // when window width is >= 640px
            1028: { slidesPerView: 3, spaceBetween: 10 },
            1536: { slidesPerView: 3, spaceBetween: 10 },
          }}
          // spaceBetween={-10}
          // slidesPerView={3.3}
          navigation={{
            // Both prevEl & nextEl are null at render so this does not work
            prevEl: navigationPrevRef.current,
            nextEl: navigationNextRef.current,
          }}
          pagination={true}
          keyboard={true}
          modules={[Navigation, Pagination, Keyboard]}
          className="h-[290px] flex py-10"
        >
          <SwiperSlide>
            <div className="w-[465px] h-[238px] rounded-[10px] shadow-lg p-5 space-y-5 xs:w-[300px]">
              <div className="flex space-x-5">
                <img src={Avatar} alt="avatar" />
                <div>
                  <p className="text-base font-inter font-semibold">
                    Lolla Smith
                  </p>
                  <p className="text-sm font-poppins font-normal">Microsoft</p>
                </div>
              </div>
              <p className="text-xs font-poppins font-normal">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make{" "}
              </p>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[465px] h-[238px] rounded-[10px] shadow-lg p-5 space-y-5 xs:w-[300px]">
              <div className="flex space-x-5">
                <img src={Avatar} alt="avatar" />
                <div>
                  <p className="text-base font-inter font-semibold">
                    Lolla Smith
                  </p>
                  <p className="text-sm font-poppins font-normal">Microsoft</p>
                </div>
              </div>
              <p className="text-xs font-poppins font-normal">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make{" "}
              </p>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[465px] h-[238px] rounded-[10px] shadow-lg p-5 space-y-5 xs:w-[300px]">
              <div className="flex space-x-5">
                <img src={Avatar} alt="avatar" />
                <div>
                  <p className="text-base font-inter font-semibold">
                    Lolla Smith
                  </p>
                  <p className="text-sm font-poppins font-normal">Microsoft</p>
                </div>
              </div>
              <p className="text-xs font-poppins font-normal">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make{" "}
              </p>
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="w-[465px] h-[238px] rounded-[10px] shadow-lg p-5 space-y-5 xs:w-[300px]">
              <div className="flex space-x-5">
                <img src={Avatar} alt="avatar" />
                <div>
                  <p className="text-base font-inter font-semibold">
                    Lolla Smith
                  </p>
                  <p className="text-sm font-poppins font-normal">Microsoft</p>
                </div>
              </div>
              <p className="text-xs font-poppins font-normal">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make{" "}
              </p>
            </div>
          </SwiperSlide>{" "}
          <SwiperSlide>
            <div className="w-[465px] h-[238px] rounded-[10px] shadow-lg p-5 space-y-5 xs:w-[300px]">
              <div className="flex space-x-5">
                <img src={Avatar} alt="avatar" />
                <div>
                  <p className="text-base font-inter font-semibold">
                    Lolla Smith
                  </p>
                  <p className="text-sm font-poppins font-normal">Microsoft</p>
                </div>
              </div>
              <p className="text-xs font-poppins font-normal">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make{" "}
              </p>
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
  );
};

export default SliderComp;
