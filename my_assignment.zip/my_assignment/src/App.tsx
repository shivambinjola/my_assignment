import React from "react";
// import "./App";
import Navbar from "./components/Navbar";
import BannerImg from "../src/assets/banner_img.png";
import Micbackimg from "../src/assets/micimgback.png";
import HeadingParaCard from "./components/HeadingParaCard";
import PlanCard from "./components/PlanCard";
import SliderComp from "./components/SliderComp";
// import PodcastImg from "./assets/podcastimg.png";
import facebookIcon from "../src/assets/facebook.png";
import youtubeIcon from "../src/assets/youtube.png";
import instagramIcon from "../src/assets/instagram.png";
import twitterIcon from "../src/assets/twitter.png";

function App() {
  return (
    <div className="bg-pageBackground bg-cover bg-no-repeat overflow-hidden">
      <div className="absolute right-0 top-[550px] xs:hidden">
        <img src={Micbackimg} alt="" />
      </div>
      <div className="md:block hidden">
        <Navbar />
      </div>
      {/* firstcomp */}
      <div className="flex flex-row justify-center lg:-space-x-3 lg:mt-32 xl:items-start lg:items-center sm:mt-20 md:space-x-2 md:space-y-0 md:flex-row sm:px-5 sm:flex-col sm:space-y-5 xs:flex-col xs:mt-10 xs:space-y-5 xs:px-5">
        <div className="text-white font-Inter xl:max-w-[530px] lg:max-w-[500px] md:max-w-[300px]  xs:min-w-[100px]">
          <h2 className="text-[48px] font-bold leading-snug xs:text-4xl">
            Learn how to launch a successful podcast
          </h2>
          <p className="text-base font-normal sm:w-[433px] mt-5 xs:text-sm ">
            Lorem Ipsum is simply dummy text of the printing and typesetting in
            ustry. Lorem Ipsum has been the industry's standard dummy text ever
            since the 1500s
          </p>
          <button className="w-[237px] h-[74.86px] text-[20px] font-poppins rounded-[10px] bg-buttonbg font-semibold mt-[66px] xs:w-[150px] xs:h-[50px] xs:text-lg xs:mt-10">
            Sign up Now
          </button>
        </div>
        <div className="xl:w-[695px] xl:h-[434px] lg:w-[465px] lg:h-[244px] xs:w-[365px] xs:h-[144px]">
          <img src={BannerImg} alt="img" />
        </div>
      </div>
      {/* sec comp */}
      <div className="flex justify-center items-center xl:space-x-32 mt-[190px] lg:space-x-5 lg:flex-row sm:flex-col-reverse  xs:flex-col-reverse">
        {/* <div className="grid grid-cols-2 "> */}
        <div className="flex xs:flex-col sm:space-x-5 space-y-8 lg:mt-0 mt-10">
          <div className=" space-y-10">
            <HeadingParaCard
              heading="Interactive Features"
              para="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been"
            />
            <HeadingParaCard
              heading="Interactive Features"
              para="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been"
            />
          </div>
          <div className="space-y-10">
            <HeadingParaCard
              heading="Interactive Features"
              para="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been"
            />
            <HeadingParaCard
              heading="Interactive Features"
              para="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been"
            />
          </div>
        </div>
        <div className=" font-Inter sm:max-w-[416px] xs:px-5 ">
          <h2 className="text-[48px] font-bold xs:text-4xl">
            About the Course
          </h2>
          <p className="text-sm font-normal mt-5">
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s, when an unkno
          </p>
          <button className="w-[237px] h-[60px] text-[20px] font-poppins rounded-[10px] bg-buttonbg font-semibold mt-10 text-white">
            Explore Now
          </button>
          {/* </div> */}
        </div>
      </div>
      {/* thirdcomp */}
      <div className="mt-20 flex flex-col items-center bg-podcastbg bg-no-repeat bg-cover py-10 sm:space-y-20 xs:space-y-5 xs:px-5">
        {/* <div>
          <img src={PodcastImg} alt="" />
        </div> */}
        <div className="text-center sm:w-[456px] ">
          <h3 className="font-Inter font-semibold text-[32px]">
            Choose your plan
          </h3>
          <p className="font-poppins font-normal text-sm mt-5">
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's
          </p>
          <div className="h-[37px] w-[166px] bg-white rounded-[10px] shadow-lg flex items-center space-x-1 mx-auto justify-center mt-10">
            <div className="w-[76px] h-[27px] bg-[#E1A6FF66]/60 rounded-[10px] text-sm font-poppins font-normal flex items-center justify-center cursor-pointer">
              monthly
            </div>
            <div className="w-[76px] h-[27px] bg-white rounded-[10px] text-sm font-poppins font-normal flex items-center justify-center cursor-pointer">
              yearly
            </div>
          </div>
        </div>
        <div className="flex xl:space-x-20 lg:space-x-5 lg:flex-row lg:space-y-0 sm:space-y-10 flex-col xs:space-y-5">
          <PlanCard
            heading="Basic Plan"
            property="bg-white"
            text="text-black"
            price="text-[#7A3199]"
          />
          <PlanCard
            heading="Premium Plan"
            property="bg-[#7A3199]"
            text="text-white"
            price="text-white"
          />
          <PlanCard
            heading="Basic Plan"
            property="bg-white"
            text="text-black"
            price="text-[#7A3199]"
          />
        </div>
      </div>
      {/* fourthcomp */}
      <div className=" mt-20 space-y-5 flex flex-col mx-auto xl:w-[1500px]  relative xl:left-48 lg:left-10 lg:w-[1000px] sm:w-[640px]">
        <div className="sm:w-[462px] space-y-3 md:px-0 sm:px-5 xs:px-5">
          <h2 className="text-[40px] font-Inter font-bold xs:text-4xl">
            Review from customers
          </h2>
          <p className="text-xs font-poppins sm:w-[399px] font-normal">
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry
          </p>
        </div>
        <SliderComp />
      </div>
      {/* fifthcomp */}
      <div className="lg:mt-32 text-center sm:w-[596px] mx-auto sm:mt-10 xs:mt-5">
        {" "}
        <h3 className="font-Inter font-semibold text-[32px]">
          We have what you’re looking for
        </h3>
        <p className="font-poppins font-normal text-sm mt-5 text-[#4776E6]">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type a
        </p>
        <button className="w-[237px] h-[60px] text-[20px] font-poppins rounded-[10px] bg-buttonbg font-semibold text-white mt-10">
          Get Started Now
        </button>
      </div>
      {/* footer */}
      <footer className=" flex sm:justify-center mt-20">
        <div className="border-t-[1px] border-white py-5 xs:w-full">
          <div className="flex lg:w-[995px] text-sm font-poppins text-white items-center xs:flex-col xs:items-start xs:space-y-2 xs:pl-5">
            <p className="">
              All Right Reserved @Copyright {new Date().getFullYear()}
            </p>
            <div className="flex md:flex-row md:space-x-2 lg:ml-44 sm:ml-10  sm:flex-col xs:flex-col">
              <p>Terms of Service</p> <p>Privacy Policy</p> <p>Product</p>
            </div>
            <div className="flex space-x-5 lg:ml-32 sm:ml-5 ">
              <img src={facebookIcon} alt="" />
              <img src={youtubeIcon} alt="" />
              <img src={instagramIcon} alt="" />
              <img src={twitterIcon} alt="" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
